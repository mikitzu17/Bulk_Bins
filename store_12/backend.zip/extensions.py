# This file can be used for other extensions like db, jwt etc if refactored.
# For now, we'll initialize Resend directly in app.py or here if preferred.